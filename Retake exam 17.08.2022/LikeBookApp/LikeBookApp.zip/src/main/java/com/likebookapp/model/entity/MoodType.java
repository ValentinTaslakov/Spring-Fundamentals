package com.likebookapp.model.entity;

public enum MoodType {
    Happy,
    Sad,
    Inspired
}
