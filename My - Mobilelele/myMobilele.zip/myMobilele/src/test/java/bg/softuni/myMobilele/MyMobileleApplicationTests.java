package bg.softuni.myMobilele;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyMobileleApplicationTests {

	@Test
	void contextLoads() {
	}

}
